import { create } from 'zustand';

interface AuthState {
  isAuthenticated: boolean;
  isAdmin: boolean;
  user: null | { id: string; name: string; email: string; role: 'user' | 'admin' };
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  isAuthenticated: false,
  isAdmin: false,
  user: null,
  login: async (email, password) => {
    // Simulate API call
    if (email === 'admin@example.com' && password === 'admin') {
      set({
        isAuthenticated: true,
        isAdmin: true,
        user: { id: '1', name: 'Admin', email, role: 'admin' },
      });
    } else if (email && password) {
      set({
        isAuthenticated: true,
        isAdmin: false,
        user: { id: '2', name: 'User', email, role: 'user' },
      });
    }
  },
  logout: () => {
    set({ isAuthenticated: false, isAdmin: false, user: null });
  },
}));