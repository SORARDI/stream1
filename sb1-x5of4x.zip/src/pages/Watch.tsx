import { ThumbsUp, ThumbsDown, Share2, Flag, Clock } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';
import { VideoCard } from '../components/VideoCard';

const VIDEO_DATA = {
  'music-101': {
    title: 'Introduction to Music Streaming',
    thumbnail: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    creator: 'Music Masters',
    subscribers: '1.8M',
    views: '1.5M',
    likes: '95K',
    description: `Discover the world of music streaming with our comprehensive guide. In this video, we cover:

• Different music genres and styles
• How to discover new artists
• Creating perfect playlists
• Music streaming quality tips

Perfect for music lovers looking to enhance their streaming experience!`
  },
  'sports-101': {
    title: 'Getting Started with Sports Streaming',
    thumbnail: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    creator: 'Sports Hub',
    subscribers: '2.2M',
    views: '1.2M',
    likes: '88K',
    description: `Your complete guide to sports streaming. This video includes:

• Live sports coverage basics
• Following your favorite teams
• Premium sports packages
• Interactive sports features

Essential viewing for sports enthusiasts!`
  },
  'entertainment-101': {
    title: 'Entertainment Streaming Guide',
    thumbnail: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    creator: 'Entertainment Plus',
    subscribers: '3.1M',
    views: '2.1M',
    likes: '150K',
    description: `Learn about entertainment streaming options. Topics covered:

• Movies and TV shows
• Original content
• Streaming quality settings
• Creating watchlists

Your gateway to endless entertainment!`
  },
  'comedy-101': {
    title: 'Comedy Streaming Essentials',
    thumbnail: 'https://images.unsplash.com/photo-1585647347483-22b66260dfff?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    creator: 'Comedy Central',
    subscribers: '2.5M',
    views: '1.8M',
    likes: '120K',
    description: `Explore the world of comedy streaming. This guide covers:

• Stand-up specials
• Comedy shows and series
• Live comedy events
• Exclusive comedy content

Get ready to laugh with our comedy streaming guide!`
  }
};

const RELATED_VIDEOS = [
  {
    id: 1,
    title: "Advanced Streaming Tips",
    thumbnail: "https://images.unsplash.com/photo-1554048612-b6a482bc67e5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    duration: "18:24",
    views: "956K",
    creator: "Stream Pro"
  },
  {
    id: 2,
    title: "Quality Settings Guide",
    thumbnail: "https://images.unsplash.com/photo-1452587925148-ce544e77e70d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    duration: "12:15",
    views: "1.1M",
    creator: "Tech Tips"
  },
  {
    id: 3,
    title: "Streaming Setup Basics",
    thumbnail: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    duration: "15:30",
    views: "784K",
    creator: "Stream Academy"
  }
];

export function Watch() {
  const [searchParams] = useSearchParams();
  const videoId = searchParams.get('v') || 'music-101';
  const video = VIDEO_DATA[videoId as keyof typeof VIDEO_DATA] || VIDEO_DATA['music-101'];

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="flex flex-col lg:flex-row gap-6">
        {/* Main Content */}
        <div className="lg:w-[70%]">
          {/* Video Player */}
          <div className="w-full aspect-video bg-black rounded-lg overflow-hidden">
            <video
              className="w-full h-full object-contain"
              controls
              poster={video.thumbnail}
            >
              <source src="" type="video/mp4" />
              Your browser does not support the video tag.
            </video>
          </div>

          {/* Video Info */}
          <div className="mt-4">
            <h1 className="text-xl font-bold">{video.title}</h1>
            <div className="flex items-center justify-between mt-2">
              <div className="flex items-center gap-4">
                <img
                  src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
                  alt="Creator"
                  className="w-10 h-10 rounded-full"
                />
                <div>
                  <p className="font-medium">{video.creator}</p>
                  <p className="text-sm text-gray-500">{video.subscribers} subscribers</p>
                </div>
                <button className="ml-4 bg-black text-white px-4 py-2 rounded-full hover:bg-gray-800">
                  Subscribe
                </button>
              </div>
              <div className="flex items-center gap-4">
                <div className="flex items-center bg-gray-100 rounded-full">
                  <button className="flex items-center gap-1 px-4 py-2 border-r border-gray-300">
                    <ThumbsUp className="w-5 h-5" />
                    <span>{video.likes}</span>
                  </button>
                  <button className="flex items-center gap-1 px-4 py-2">
                    <ThumbsDown className="w-5 h-5" />
                  </button>
                </div>
                <button className="flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-full">
                  <Share2 className="w-5 h-5" />
                  Share
                </button>
                <button className="p-2 hover:bg-gray-100 rounded-full">
                  <Flag className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="mt-4 bg-gray-100 rounded-xl p-4">
            <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
              <span>{video.views} views</span>
              <span>•</span>
              <span>2 months ago</span>
            </div>
            <p className="text-sm text-gray-800 whitespace-pre-line">
              {video.description}
            </p>
          </div>
        </div>

        {/* Sidebar */}
        <div className="lg:w-[30%]">
          <div className="flex items-center gap-2 mb-4">
            <button className="px-4 py-2 bg-gray-100 rounded-full text-sm font-medium">All</button>
            <button className="px-4 py-2 bg-gray-100 rounded-full text-sm font-medium">Related</button>
            <button className="px-4 py-2 bg-gray-100 rounded-full text-sm font-medium">From {video.creator}</button>
          </div>
          <div className="flex flex-col gap-4">
            {RELATED_VIDEOS.map((video) => (
              <VideoCard
                key={video.id}
                title={video.title}
                thumbnail={video.thumbnail}
                duration={video.duration}
                views={video.views}
                creator={video.creator}
                className="!block"
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}